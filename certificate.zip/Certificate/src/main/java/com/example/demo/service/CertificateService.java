package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Certificate;

public interface CertificateService {

 public Certificate saveCertificate(Certificate certificate);
 
 public List< Certificate>  fetchCertificateList();
 
 public Certificate fetchCertificateById(Long certificateId);
 
 public void deleteCertificateById(Long certificateId);

public Certificate updateCertificate(Long id, Certificate certificate);

public static Optional<Certificate> findById(Long id) {
	// TODO Auto-generated method stub
	return null;
}
 
 //public Certificate updateCertificate(Long certificateId,Certificate certificate);
 
}
